package PaSkCode;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.RenderingHints;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.Image;
import javax.imageio.ImageIO;
import java.io.IOException;

public class GWView extends PSysView
{
	GWView()
	{
		
	}
	
	void draw(GWModel model,Graphics graph)
	{
		
		for(int i=0; i<model.spriteList.size(); i++)
		{
			graph.drawImage(model.spriteList.get(i).getImage(), model.spriteList.get(i).newPart.x,
					model.spriteList.get(i).newPart.y, 2*model.spriteList.get(i).newPart.radius,
						2*model.spriteList.get(i).newPart.radius, null);
		}
	}
	
	
}