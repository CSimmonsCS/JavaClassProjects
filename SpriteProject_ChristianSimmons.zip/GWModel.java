package PaSkCode;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.RenderingHints;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.Image;
import javax.imageio.ImageIO;
import java.io.IOException;

public class GWModel extends PSysModel
{
	ArrayList<Sprite> spriteList;
	ArrayList<Character> itemType;
	Image img, grave;

	
	GWModel()
	{
		spriteList = new ArrayList<Sprite>();
		itemType = new ArrayList<Character>();
	}
	
	void addPlayer(int rad, int npx, int npy, int nvx, int nvy, Image pImg)
	{
		itemType.add('c');
		spriteList.add(new Sprite(rad, npx, npy, nvx, nvy, pImg));
	}
	
	void keyReleased(KeyEvent e){
		int key=e.getKeyCode();
		int i=1;

		switch(key){
		
			case KeyEvent.VK_LEFT:	
				spriteList.get(i).newPart.velX = 0;break;
			
			case KeyEvent.VK_RIGHT:
				spriteList.get(i).newPart.velX = 0;break;
			
			case KeyEvent.VK_UP:
				spriteList.get(i).newPart.velY = 0;break;
			
			case KeyEvent.VK_DOWN:
				spriteList.get(i).newPart.velY = 0;break;
			
			case KeyEvent.VK_SPACE:
				if(itemType.get(i)=='c')
					
					
				addProjectile(img, 1);
				
				
			break;
		}
	}

	void keyPressed(KeyEvent e){
		int key=e.getKeyCode();
		int i=1;	
		
		if(itemType.get(i)=='c'){
			switch(key){
				case KeyEvent.VK_LEFT:
					spriteList.get(i).newPart.velX = -5;break;		
				
				case KeyEvent.VK_RIGHT:
					spriteList.get(i).newPart.velX = 5;	break;
					
				case KeyEvent.VK_UP:
					spriteList.get(i).newPart.velY = -5;break;
				
				case KeyEvent.VK_DOWN:
					spriteList.get(i).newPart.velY = 5;break;
				
				case KeyEvent.VK_SPACE:break;
			}
		}
	}
	
	void addBot(int rad, int npx, int npy, int nvx, int nvy, Image sImg)
	{
		itemType.add('b');
		spriteList.add(new Sprite(rad, npx, npy, nvx, nvy, sImg));

	}
	
	void orientBots()
	{
		int spriteSize = spriteList.size();
		for(int i=0; i < spriteSize; i++){
			if(itemType.get(i)=='b')
			{
				if(spriteList.get(i).newPart.x>spriteList.get(1).newPart.x)
				{
					spriteList.get(i).newPart.velX = -1;
				}
				else if(spriteList.get(i).newPart.x<=spriteList.get(1).newPart.x)
				{
					spriteList.get(i).newPart.velX = 1;
				}
				if(spriteList.get(i).newPart.y>spriteList.get(1).newPart.y)
				{
					spriteList.get(i).newPart.velY = -1;
				}
				else if(spriteList.get(i).newPart.y<=spriteList.get(1).newPart.y)
				{
					spriteList.get(i).newPart.velY = 1;
				}
				addProjectile(img, i);
			}		
		}
	}

	void checkCollide(){
		
		for(int i =0; i<spriteList.size(); i++)
		{
			for(int j =0; j<spriteList.size(); j++)
			{
				if(j!=i)
				{
					if(isOverlap(spriteList.get(i).newPart, spriteList.get(j).newPart))
					{
						if(itemType.get(i)=='c')
						{
							killChar(i);
						}
						if(itemType.get(i)=='b')
						{
							killChar(i);
						}
						if(itemType.get(i)=='p')
						{
							removeProj(i);	
						}		
						if(itemType.get(j)=='c')
						{
							killChar(j);
						}
						if(itemType.get(j)=='b')
						{
							killChar(j);
						}
						if(itemType.get(j)=='p')
						{
							removeProj(j);
							
						}
						
					}
				}							
			}		
		}
	}

	boolean isOverlap(Particle p1, Particle p2) 
	{
		int X = Math.abs(p1.x - p2.x);
		
		int Y = Math.abs(p1.y - p2.y);
		
		if (X < p1.radius + p2.radius && Y < p1.radius + p2.radius)
			return true;
		else
			return false;
		
	}



	void update(int bw, int bh)
	{
		for(int i =0; i<spriteList.size(); i++)
		{
			spriteList.get(i).newPart.update(bw,bh);
		}
	}	
	
	void addProjectileImg(Image img){
		this.img=img;
	}

	void addGraveStone(Image img){
		grave = img;

	}
	void addProjectile(Image img, int index)
	{
		int offX=0;
		int offY=0;
		int X = spriteList.get(index).newPart.x;
		int Y = spriteList.get(index).newPart.y;
		
		int VX = spriteList.get(index).newPart.velX;
		int VY = spriteList.get(index).newPart.velY;
		
		int rad = spriteList.get(index).newPart.radius;

		
		if(VX>0)
		{
			offX=rad;
		}
		else if(VX<0)
		{
			offX=-(1+rad*2);
		}
		if(VY>0)
		{
			offY=rad;
		}
		else if(VY<0)
		{
			offY=-(1+rad*2);
		}		
		
		int newX = X+rad*3/4+offX;
		int newY = Y+rad*3/4+offY;
		
		if(VX>0 || VY>0 || VX<0|| VY<0)
		{
			spriteList.add(new Sprite(10,newX,newY,VX*2,VY*2,img));
			itemType.add('p');
		}
	}
	
	
	void killChar(int index)
	{
		
		int prevX = spriteList.get(index).newPart.x;
		int prevY = spriteList.get(index).newPart.y;
		int rad = spriteList.get(index).newPart.radius;

		
		spriteList.set(index, new Sprite(rad ,prevX, prevY, 0, 0, grave));
		
		itemType.set(index,'t');
	}

	void removeProj(int index)
	{
		itemType.set(index, 'e');
		spriteList.set(index, new Sprite(0, 0, 0, 0, 0, grave));

	}

}