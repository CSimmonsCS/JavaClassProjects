package PaSkCode;

public class Particle{
	int rad;
	int x;
	int y;
	int velx;
	int vely;
	
	Particle()
	{
		rad = 0;
		x = 0;
		y = 0;
		velx = 0;
		vely = 0;
	}
	
	Particle(int rad, int x, int y, int velx, int vely)
	{
		this.rad = rad;
		this.x = x;
		this.y = y;
		this.velx = velx;
		this. vely = vely;
		
	}
	
}