package PaSkCode;

import java.util.ArrayList;

public class PSysModel {
    // ArrayList or similar of particles
    // each particle: x, y, velX, velY, radius
	
	ArrayList <Particle> particles;
	int index;

    PSysModel() {
	// instantiate list of particles
    	particles = new ArrayList<Particle>();
    	index = 0;
    	
    	
    }

    // add a particle to list
    void add(int rad, int x, int y, int vx, int vy) {
    	
    	Particle part = new Particle(rad, x, y, vx, vy);
    	
    	
	    particles.add(index, part);
	    index++;
	    
	    
	    
	    
    	
    }


    // update state of each particle in list
    void update(int bw, int bh) {
    	
    	for(int i = 0; i<index; i++)
    	{
    	
    	particles.get(i).x += particles.get(i).velx;
    	particles.get(i).y += particles.get(i).vely;

    	if (particles.get(i).x >= bw-particles.get(i).rad && particles.get(i).velx > 0) {
    		particles.get(i).velx = -particles.get(i).velx;
    	}
    	else if (particles.get(i).x < particles.get(i).rad && particles.get(i).velx < 0) {
    		particles.get(i).velx = -particles.get(i).velx;
    	}

    	if (particles.get(i).y >= bh-particles.get(i).rad && particles.get(i).vely > 0) {
    		particles.get(i).vely = -particles.get(i).vely;
    	}
    	else if (particles.get(i).y < particles.get(i).rad && particles.get(i).vely < 0) {
    		particles.get(i).vely = -particles.get(i).vely;
    	}
    	
    	}
    }
}